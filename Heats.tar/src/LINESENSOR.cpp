#include "mbed.h"
#include "config.h"
#include "LINESENSOR.h"

LineSensor::LineSensor(PinName enablePin1, PinName enablePin2,
               PinName pin1, PinName pin2, PinName pin3, PinName pin4, PinName pin5): 
            enablePin1(enablePin1), enablePin2(enablePin2),
            sensor1(pin1), sensor2(pin2), sensor3(pin3), sensor4(pin4), sensor5(pin5) {
                for(int i = 0; i<sensor_1_buffer_size; i++){
                    sensor1_values[i] = 0.0;                                   
                }
                for(int i = 0; i<sensor_2_buffer_size; i++){
                    sensor2_values[i] = 0.0;                                   
                }
                for(int i = 0; i<sensor_3_buffer_size; i++){
                    sensor3_values[i] = 0.0;                                   
                }
                for(int i = 0; i<sensor_4_buffer_size; i++){
                    sensor4_values[i] = 0.0;                                   
                }
                for(int i = 0; i<sensor_5_buffer_size; i++){
                    sensor5_values[i] = 0.0;                                   
                }
                sensor1_index = 0;
                sensor2_index = 0;
                sensor3_index = 0;
                sensor4_index = 0;
                sensor5_index = 0;
                
                lastcounts = 0;

                sensor1Max = DEFAULT_SENSOR_1_MAX;
                sensor1Min = DEFAULT_SENSOR_1_MIN;
    
                sensor2Max = DEFAULT_SENSOR_2_MAX;
                sensor2Min = DEFAULT_SENSOR_2_MIN;

                sensor3Max = DEFAULT_SENSOR_3_MAX;
                sensor3Min = DEFAULT_SENSOR_3_MIN;

                sensor4Max = DEFAULT_SENSOR_4_MAX;
                sensor4Min = DEFAULT_SENSOR_4_MIN;

                sensor5Max = DEFAULT_SENSOR_5_MAX;
                sensor5Min = DEFAULT_SENSOR_5_MIN;
            }

double LineSensor::normalize(int sensorNumber){
    double output = 0.0;
    switch(sensorNumber){
        case 1:
            output = (averageSensorValue1 - sensor1Min) / (sensor1Max - sensor1Min);
            if(output < sensor1Min){return 0.0;}
            if(output > sensor1Max){return 1.0;}
            return output;
        case 2:
            output = (averageSensorValue2 - sensor2Min) / (sensor2Max - sensor2Min);
            if(output < sensor2Min){return 0.0;}
            if(output > sensor2Max){return 1.0;}
            return output;
        case 3:
            output = (averageSensorValue3 - sensor3Min) / (sensor3Max - sensor3Min);
            if(output < sensor3Min){return 0.0;}
            if(output > sensor3Max){return 1.0;}
            return output;
        case 4:
            output = (averageSensorValue4 - sensor4Min) / (sensor4Max - sensor4Min);
            if(output < sensor4Min){return 0.0;}
            if(output > sensor4Max){return 1.0;}
            return output;
        case 5:
            output = (averageSensorValue5 - sensor5Min) / (sensor5Max - sensor5Min);
            if(output < sensor5Min){return 0.0;}
            if(output > sensor5Max){return 1.0;}
            return output;
        default:
            return -1.0;
    }
}

void LineSensor::readAll(){
    readSensorValues(1);
    readSensorValues(2);
    readSensorValues(3);
    readSensorValues(4);
    readSensorValues(5);
}

void LineSensor::readSensorValues(int sensorNumber){
    switch (sensorNumber){
        case 1:
            sensor1_values[sensor1_index] = sensor1.read();
            sensor1_index++; sensor1_index %= sensor_1_buffer_size;
            break;
        case 2:
            sensor2_values[sensor2_index] = sensor2.read();
            sensor2_index++; sensor2_index %= sensor_2_buffer_size;
            break;
        case 3:
            sensor3_values[sensor3_index] = sensor3.read();
            sensor3_index++; sensor3_index %= sensor_3_buffer_size;
            break;
        case 4:
            sensor4_values[sensor4_index] = sensor4.read();
            sensor4_index++; sensor4_index %= sensor_4_buffer_size;
            break;
        case 5:
            sensor5_values[sensor5_index] = sensor5.read();
            sensor5_index++; sensor5_index %= sensor_5_buffer_size;
            break;
        default:
            break;

    }
}

void LineSensor::start_sampling_all(float sample_period){
    t.attach(callback(this, &LineSensor::readAll), sample_period);
}

void LineSensor::stop_sampling_all(){
    t.detach();
}

void LineSensor::enableBank1() { enablePin1 = 1; }
void LineSensor::disableBank1() { enablePin1 = 0; }

void LineSensor::enableBank2() { enablePin2 = 1; }
void LineSensor::disableBank2() { enablePin2 = 0; }

float LineSensor::getAverageSensorValue(int sensorNumber, bool normalize_data){
    double sum = 0.0;
    switch (sensorNumber){
        case 1:
            for(int i = 0; i<sensor_1_buffer_size; i++){
                sum += sensor1_values[i];
            }
            averageSensorValue1 = sum / (float)(sensor_1_buffer_size);
            if(normalize_data){return normalize(1);}
            else{return averageSensorValue1;}
        case 2:
            for(int i = 0; i<sensor_2_buffer_size; i++){
                sum += sensor2_values[i];
            }
            averageSensorValue2 = sum / (float)(sensor_2_buffer_size);
            if(normalize_data){return normalize(2);}
            else{return averageSensorValue2;}
        case 3:
            for(int i = 0; i<sensor_3_buffer_size; i++){
                sum += sensor3_values[i];
            }
            averageSensorValue3 = sum / (float)(sensor_3_buffer_size);
            if(normalize_data){return normalize(3);}
            else{return averageSensorValue3;}
        case 4:
            for(int i = 0; i<sensor_4_buffer_size; i++){
                sum += sensor4_values[i];
            }
            averageSensorValue4 = sum / (float)(sensor_4_buffer_size);
            if(normalize_data){return normalize(4);}
            else{return averageSensorValue4;}
        case 5:
            for(int i = 0; i<sensor_5_buffer_size; i++){
                sum += sensor5_values[i];
            }
            averageSensorValue5 = sum / (float)(sensor_5_buffer_size);
            if(normalize_data){return normalize(5);}
            else{return averageSensorValue5;}
        default:
            return -1.0;
    }
}

void LineSensor::setSensorMax(int sensorNumber, double maxValu){
    switch(sensorNumber){
        case 1:
            sensor1Max = maxValu;
            break;
        case 2:
            sensor2Max = maxValu;
            break;
        case 3:
            sensor3Max = maxValu;
            break;
        case 4:
            sensor4Max = maxValu;
            break;
        case 5:
            sensor5Max = maxValu;
            break;
        default:
            return;
    }
}

void LineSensor::setSensorMin(int sensorNumber, double minValu){
    switch(sensorNumber){
        case 1:
            sensor1Min = minValu;
            break;
        case 2:
            sensor2Min = minValu;
            break;
        case 3:
            sensor3Min = minValu;
            break;
        case 4:
            sensor4Min = minValu;
            break;
        case 5:
            sensor5Min = minValu;
            break;
        default:
            return;
    }
}

double LineSensor::getSensorMax(int sensorNumber){
    switch(sensorNumber){
        case 1:
            return sensor1Max;
            break;
        case 2:
            return sensor2Max;
            break;
        case 3:
            return sensor3Max;
            break;
        case 4:
            return sensor4Max;
            break;
        case 5:
            return sensor5Max;
            break;
        default:
            return -1.0;
    }
}

double LineSensor::getSensorMin(int sensorNumber){
    switch(sensorNumber){
        case 1:
            return sensor1Min;
            break;
        case 2:
            return sensor2Min;
            break;
        case 3:
            return sensor3Min;
            break;
        case 4:
            return sensor4Min;
            break;
        case 5:
            return sensor5Min;
            break;
        default:
            return -1.0;
    }
}