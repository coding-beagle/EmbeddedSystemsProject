#include "mbed.h"
#include "PID.h"
#include "ENCODERS.h"
#include "config.h"
#include "LINESENSOR.h"
#include "BLEMODULE.h"

enum programState {normal, showdata, calculatePID,stop, reset_controllers, togglePrint, change_val, calibrate_sensors, print_sensor_values, measure_values, do_uturn_stuff, return_to_normal_after_finished_turn};
programState state = normal;

enum valueToChange {speed1, speed2, pro1, int1, der1, pro2, int2, der2, pro3, int3, der3, pro4, int4, der4, slow_cond, slow_speed_val, turn_speed_val} value=speed1;
float changeTo = 0.0;

void printData(){
    state = showdata;
}

void calcPID(){
    state = calculatePID;
}

volatile double desired_speed_1 = 0.0;
volatile double desired_speed_2 = 0.0;
volatile double prev_desired_speed_1 = 0.0;
volatile double prev_desired_speed_2 = 0.0;
volatile int desired_direction_1 = 1, desired_direction_2 = 0;
volatile int prev_dir_1 = 0, prev_dir_2 = 0;
bool use_slow = true, isTurning = true;

DigitalOut direction1(DIRECTION1);
DigitalOut direction2(DIRECTION2);

DigitalOut led(LED2);

bool printingEncoders = false;

void toggle_led(){
    led = !led;
}

void toggle_print(){
    printingEncoders = !printingEncoders;
}

bool printSerial;

void toggle_print_serial(){
    printSerial = !printSerial;
}

Timeout revert;

bool enabledStopCondition;
bool useSensors;

void toggleStopCondition(){
    enabledStopCondition = !enabledStopCondition;
    printf("Toggling Stop Cond\n");
}

DigitalOut enable(ENABLE_PIN);
bool toggle_interp = true;

Ticker t;
Ticker t2;
// Ticker t3;

void measure_sensors(){
    state = measure_values;
}

void enable_tickers(){
    t.attach(&printData, DATA_MEASURE_FREQ);
    t2.attach(&calcPID, PID_ENCODER_FREQ);
    // t3.attach(&measure_sensors, LINESENSOR_POLL_RATE);
}

void disable_tickers(){
    t.detach();
    t2.detach();
    // t3.detach();
}

void go_to_calibrate_sensors(){
    state = calibrate_sensors;
}

void read_sensor_vals(){
    // printf("Disabling Tickers");
    disable_tickers();
    wait(0.2);
    t.attach(&go_to_calibrate_sensors, PID_ENCODER_FREQ);
}

Timeout turn;

void reenable_sensors(){
    useSensors = true;
}

void back_to_normal_after_turn(){
    state = return_to_normal_after_finished_turn;
}

void go_to_turn_state(){
    state = do_uturn_stuff;
}

void uturn_start(){
    // printf("executing turn");
    isTurning = false;
    disable_tickers();
    prev_desired_speed_1 = desired_speed_1;
    prev_desired_speed_2 = desired_speed_2;
    t.attach(&go_to_turn_state, 0.001);
}

double error_scale = 1.0;

void stopStart(){
    enable = !enable;
    disable_tickers();
    state = reset_controllers;
}

void use_sensors(){
    useSensors = !useSensors;
}

void changeValueBeingSet(int val){
    value = (valueToChange)(val);
}

void setValueTo(float val){
    changeTo = val;
    state = change_val;
}

void setValueToQuick(int val){
    changeTo = (float)val/10;
    state = change_val;
}

void speedsTo(int val){         // quick speed setting shortcut
    enable = 0;
    desired_speed_1 = (float)(val)/10;
    desired_speed_2 = (float)(val)/10;
    prev_desired_speed_1 = (float)(val)/10;
    prev_desired_speed_2 = (float)(val)/10;
    wait(0.1);
    enable = 1;
}

void disable_motors(){
    enable = 0;
}

void enable_motors(){
    enable = 1;
}

void change_interp(){
    toggle_interp = !toggle_interp;
}

#ifdef USE_RC_MODE
void stop_all_commands(){
    desired_speed_1 = 0.0;
    desired_speed_2 = 0.0;
}

Timeout stop_after_command;

void forward(){
    desired_speed_1 = 2.0;
    desired_speed_2 = 2.0;
    desired_direction_1 = 0;
    desired_direction_2 = 1;
    stop_after_command.attach(&stop_all_commands, 0.1);
}

void backward(){
    desired_speed_1 = 2.0;
    desired_speed_2 = 2.0;
    desired_direction_1 = 1;
    desired_direction_2 = 0;
    stop_after_command.attach(&stop_all_commands, 0.1);
}

void left(){
    desired_speed_1 = 2.0;
    desired_speed_2 = 2.0;
    desired_direction_1 = 1;
    desired_direction_2 = 1;
    stop_after_command.attach(&stop_all_commands, 0.1);
}

void right(){
    desired_speed_1 = 2.0;
    desired_speed_2 = 2.0;
    desired_direction_1 = 0;
    desired_direction_2 = 0;
    stop_after_command.attach(&stop_all_commands, 0.1);
}
#endif

void toggle_use_slow(){
    use_slow = !use_slow;
}

void go_to_normal(){
    t.detach();
    printf("Stopping");
    wait(0.2);
    state = print_sensor_values;
    direction1 = 1;
    direction2 = 0;
}

double ACCELERATION_RATE = ACCELERATION_RATE_PER_TICK;

// void revert_to_normal_speeds_after_turn(){
//     disable_tickers();
//     desired_speed_1 = 8.0;
//     desired_speed_2 = 8.0;
//     enable_tickers();
//     // ACCELERATION_RATE = 0.001;
// }

double map(double x, double in_min, double in_max, double out_min, double out_max) {
    double val = (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
    if (val > out_max){return out_max;}
    if (val < out_min){return out_min;}
    else{return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;}
}

int main() {
    enable = 1;

    Serial pc(USBTX, USBRX);

    led = 0;

    toggle_interp = true;

    useSensors = true;

    enabledStopCondition = false;

    HM10 ble(BLE_PINS_TUPLE);

    PwmOut pwm1(MOTOR1PWM);
    pwm1.period(Period);
    pwm1.write(1.0);

    PwmOut pwm2(MOTOR2PWM);
    pwm2.period(Period);
    pwm2.write(1.0);

    int ble_errors = 0;

    ble_errors += ble.addCallback(TOGGLE_LED_SIGNAL, &toggle_led);
    ble_errors += ble.addCallback(TOGGLE_PRINT_ENCODERS_SIGNAL, &toggle_print);
    ble_errors += ble.addCallback(TOGGLE_PRINT_SERIAL_SIGNAL, &toggle_print_serial);
    ble_errors += ble.addCallback(TOGGLE_STOP_COND_SIGNAL, &toggleStopCondition);       // Signal for turning on / off automatic stopping when no line is sensed
    ble_errors += ble.addCallback(TOGGLE_INTERPOLATION, &change_interp);
    ble_errors += ble.addCallback(TOGGLE_ENABLE_SIGNAL, &stopStart);
    ble_errors += ble.addCallback(TOGGLE_SENSOR_USAGE_SIGNAL, &use_sensors);
    ble_errors += ble.addCallback(TOGGLE_USE_SLOW_SIGNAL, &toggle_use_slow);

    ble_errors += ble.addCallback(CHANGE_VALUE_SIGNAL, &setValueTo);                    // uses FLOAT as arg for change value
    ble_errors += ble.addCallback(CHANGE_VALUE_QUICK_SIGNAL, &setValueToQuick);         // uses INT as arg for change value instead of float.
    ble_errors += ble.addCallback(CHANGE_VALUE_BEING_CHANGED_SIGNAL, &changeValueBeingSet);
    ble_errors += ble.addCallback(SET_SPEED_QUICK, &speedsTo);   

    ble_errors += ble.addCallback(ENABLE_MOTORS_SIGNAL, &disable_motors);
    ble_errors += ble.addCallback(DISABLE_MOTORS_SIGNAL, &enable_motors);

    ble_errors += ble.addCallback(ENABLE_TICKERS_SIGNAL, &enable_tickers);
    ble_errors += ble.addCallback(DISABLE_TICKERS_SIGNAL, &disable_tickers);

    ble_errors += ble.addCallback(ROTATE_180_SIGNAL, &uturn_start);
    ble_errors += ble.addCallback(CALIBRATE_SENSORS_SIGNAL, &read_sensor_vals);

    #ifdef USE_RC_MODE
    ble_errors += ble.addCallback(FORWARD_SIGNAL, &forward);
    ble_errors += ble.addCallback(BACKWARD_SIGNAL, &backward);
    ble_errors += ble.addCallback(LEFT_SIGNAL, &left);
    ble_errors += ble.addCallback(RIGHT_SIGNAL, &right);
    #endif

    if(ble_errors != 0){
        pc.printf("Error Adding BLE Callbacks!");
        for(;;){
            led = !led;
            wait(0.2);
        }
    }

    direction1 = 0;
    direction2 = 1;

    t.attach(&printData, DATA_MEASURE_FREQ);
    t2.attach(&calcPID, PID_ENCODER_FREQ);
    // t3.attach(&measure_sensors, LINESENSOR_POLL_RATE);

    DigitalOut bipolar1(BIPOLAR1);
    bipolar1 = 0;
    
    DigitalOut bipolar2(BIPOLAR2);
    bipolar2 = 0;

    Encoder encoder1(ENCODER1_CHA, ENCODER1_CHB, 256, 0.08, ENCODER_MEASURE_RATE);
    Encoder encoder2(ENCODER2_CHA, ENCODER2_CHB, 256, 0.08, ENCODER_MEASURE_RATE);

    PIDController first_motor_controller(DEFAULT_MOTOR1_P, DEFAULT_MOTOR1_I, DEFAULT_MOTOR1_D, PID_ENCODER_FREQ);
    PIDController second_motor_controller(DEFAULT_MOTOR2_P, DEFAULT_MOTOR2_I, DEFAULT_MOTOR2_D, PID_ENCODER_FREQ);
    PIDController navigation_controller(DEFAULT_NAVIGATION_P, DEFAULT_NAVIGATION_I, DEFAULT_NAVIGATION_D, PID_ENCODER_FREQ);

    // pwm1.write(0.5);
    // pwm2.write(0.5);    

    double write_val1;
    double write_val2;

    DigitalIn button(USER_BUTTON);

    LineSensor lineSensorManager(SENSOR_BANK_1_PIN, SENSOR_BANK_2_PIN, LINE_SENSOR_1_PIN, LINE_SENSOR_2_PIN, LINE_SENSOR_3_PIN, LINE_SENSOR_4_PIN, LINE_SENSOR_5_PIN);

    lineSensorManager.enableBank1();
    lineSensorManager.enableBank2();

    double navigation_bias = 0.0;
    double bank_1_difference = 0.0;
    double bank_2_difference = 0.0;
    double avg_value = 0.0;
    double avg_difference = 0.0;

    double slow_speed = SLOW_CORNER_SPEED;
    double slow_condition = 0.4;

    // for interpolation
    double current_speed_1 = 0.0;
    double current_speed_2 = 0.0;
    double last_tick_current_speed_1 = 0.0;
    double last_tick_current_speed_2 = 0.0;

    double last_tick_desired_speed_1 = 0.0;
    double last_tick_desired_speed_2 = 0.0;

    double current_write_val_1 = 0.0;
    double current_write_val_2 = 0.0;
    double last_tick_write_val_1 = 0.0;
    double last_tick_write_val_2 = 0.0;

    double pid_output_1 = 0.0;
    double pid_output_2 = 0.0;

    double sensor_1_read = 0.0;
    double sensor_2_read = 0.0;
    double sensor_3_read = 0.0;
    double sensor_4_read = 0.0;
    double sensor_5_read = 0.0;

    Timeout return_to_normal_speed;

    bool calculatingPID = false;
    bool decelerating = false;
    printSerial = false;

    double turning_speed = DEFAULT_TURN_SPEED;

    bool canStopTurning = false;

    bool calibrating_sensors = false;
    Timeout stop_calibrating_sensors;

    Timeout turn_timeout;
    
    int calibration_count = 0;
    int turn_count = 0;

    int stop_count = 0;

    lineSensorManager.start_sampling_all(LINESENSOR_POLL_RATE);

    // wait(1);// wait for everything to init
    
    while(1) {

        switch (state){
            case normal:
                
                ble.doBLE();

                if(!button){
                    // printf("Button Pressed");
                    // timer.start();
                    wait(0.2);
                    read_sensor_vals();
                }

                break;
            case showdata:
                if(!calculatingPID and printSerial){
                    if(printingEncoders){
                        printf("RPS1 = %f\n", encoder1.getRPS());
                        printf("RPS2 = %f\n", encoder2.getRPS());
                        printf("DESIRED3 = %f\n", current_speed_1 + navigation_bias);
                        printf("DESIRED4 = %f\n", current_speed_2 - navigation_bias);
                    }
                    else{
                        printf("Sensor1 = %f\n", lineSensorManager.getAverageSensorValue(1));
                        printf("Sensor2 = %f\n", lineSensorManager.getAverageSensorValue(2));
                        printf("Sensor3 = %f\n", lineSensorManager.getAverageSensorValue(3));
                        printf("Sensor4 = %f\n", lineSensorManager.getAverageSensorValue(4));
                        printf("Sensor5 = %f\n", lineSensorManager.getAverageSensorValue(5));                                                  
                    }
                }
                state = normal;
                break;

            case calculatePID:
                calculatingPID = true;
                
                bank_1_difference = lineSensorManager.getAverageSensorValue(2) - lineSensorManager.getAverageSensorValue(1);
                bank_2_difference = lineSensorManager.getAverageSensorValue(3) - lineSensorManager.getAverageSensorValue(4);
                
                double avg_difference = (bank_1_difference + bank_2_difference)*0.5;

                

                // basic interpolation
                if(toggle_interp){
                    current_speed_1 = (desired_speed_1 * ACCELERATION_RATE) + last_tick_current_speed_1*(1-ACCELERATION_RATE);
                    if(current_speed_1 < 0.2){current_speed_1 = 0.0;}
                    last_tick_current_speed_1 = current_speed_1;
                    

                    current_speed_2 = (desired_speed_2 * ACCELERATION_RATE) + last_tick_current_speed_2*(1-ACCELERATION_RATE);
                    if(current_speed_2 < 0.2){current_speed_2 = 0.0;}
                    last_tick_current_speed_2 = current_speed_2;
                }
                else{
                    current_speed_1 = desired_speed_1;
                    current_speed_2 = desired_speed_2;
                    last_tick_current_speed_1 = current_speed_1;
                    last_tick_current_speed_2 = current_speed_2;
                }

                // scale error logarithmically based on the current speeds
                // error_scale = (current_speed_1 + current_speed_2)/2;
                // error_scale = 20 * pow(0.01 * error_scale, 0.5);
                // if(error_scale < 0.5){
                //     error_scale = 0.5;
                // }
                error_scale = 1.0;

                if(useSensors){
                    if(abs(bank_2_difference) < 0.3){
                        navigation_bias = navigation_controller.calculate((bank_1_difference*BANK_1_WEIGHT) * error_scale, 0.0);
                    }
                    if (abs(bank_2_difference) >= 0.3){
                        navigation_bias = navigation_controller.calculate(((bank_1_difference*BANK_1_WEIGHT) + (bank_2_difference * BANK_2_WEIGHT)) * error_scale, 0.0);
                    }
                }
                else{
                    navigation_bias = 0.0;
                }

                if(use_slow){
                    if((lineSensorManager.getAverageSensorValue(5) < FRONT_SENSOR_SLOW_CONDITION || abs(bank_1_difference) < BANK_1_SLOW_CONDITION) && !decelerating && desired_speed_1 > slow_speed){
                        toggle_interp = false;
                        decelerating = true;
                        prev_desired_speed_1 = desired_speed_1;
                        prev_desired_speed_2 = desired_speed_2;
                        desired_speed_1 = map(lineSensorManager.getAverageSensorValue(5), 0.0, 1.0, slow_speed,prev_desired_speed_1);
                        desired_speed_2 = map(lineSensorManager.getAverageSensorValue(5), 0.0, 1.0, slow_speed,prev_desired_speed_1);
                        
                    }
                    else{
                        decelerating = false;
                        toggle_interp = true;
                        desired_speed_1 = prev_desired_speed_1;
                        desired_speed_2 = prev_desired_speed_2;
                    }
                }

                if(enabledStopCondition){
                    if(lineSensorManager.getAverageSensorValue(5) < FRONT_SENSOR_STOP_CONDITION && lineSensorManager.getAverageSensorValue(1) < BANK_1_STOP_CONDITION && lineSensorManager.getAverageSensorValue(2) < BANK_1_STOP_CONDITION && lineSensorManager.getAverageSensorValue(3) < BANK_2_STOP_CONDITION && lineSensorManager.getAverageSensorValue(4) < BANK_2_STOP_CONDITION){
                        stop_count++;
                        if(stop_count > STOP_COUNTER_STOP_VAL){
                            state = stop;
                            break;
                        }
                    }
                    else{
                        // desired_speed_1 = prev_desired_speed_1;
                        // desired_speed_2 = prev_desired_speed_2;
                        stop_count = 0;
                    }
                
                }
                

                // if(desired_speed_1 != prev_desired_speed_1 && toggle_interp){
                //     desired_speed_1 = (desired_speed_1 * ) 
                // }

                double first_motor_controller_set_point = current_speed_1 + navigation_bias;
                if(first_motor_controller_set_point < 0.0 && first_motor_controller_set_point > REVERSE_MOTOR_FOR_TURN_THRESHOLD){
                    first_motor_controller_set_point = -1.0;    // brake aggressively
                    direction1 = desired_direction_1;
                }
                else if (first_motor_controller_set_point < REVERSE_MOTOR_FOR_TURN_THRESHOLD){
                    direction1 = !desired_direction_1;
                    first_motor_controller_set_point = abs(first_motor_controller_set_point) * 0.5;
                }
                else{
                    direction1 = desired_direction_1;
                }
                pid_output_1 = 0.0;
                pid_output_1 = - first_motor_controller.calculate(encoder1.getRPS(), first_motor_controller_set_point);        
                current_write_val_1 = (pid_output_1 * SMOOTHING_OF_WRITE_VAL_PER_TICK) + last_tick_write_val_1 * (1 - SMOOTHING_OF_WRITE_VAL_PER_TICK); // smooth out write vals to prevent spikes
                current_write_val_1 = (current_write_val_1 > 1.0) ? 1.0 : (current_write_val_1 <= 0.0) ? 0.0 : current_write_val_1;
                if(desired_speed_1 < 0.1){pwm1.write(1.0);}
                else{pwm1.write(current_write_val_1);}

                // last_tick_write_val_1 = current_write_val_1;

                double second_motor_controller_set_point = current_speed_2 - navigation_bias;
                if(second_motor_controller_set_point < 0.0 && second_motor_controller_set_point > REVERSE_MOTOR_FOR_TURN_THRESHOLD){
                    second_motor_controller_set_point = -1.0;
                    direction2 = desired_direction_2;
                }
                else if (second_motor_controller_set_point < REVERSE_MOTOR_FOR_TURN_THRESHOLD){
                    direction2 = !desired_direction_2;
                    second_motor_controller_set_point = abs(second_motor_controller_set_point) * 0.5;
                }
                else{
                    direction2 = desired_direction_2;
                }
                pid_output_2 = 0.0;
                pid_output_2 = - second_motor_controller.calculate(encoder2.getRPS(), second_motor_controller_set_point);        
                current_write_val_2 = (pid_output_2 * SMOOTHING_OF_WRITE_VAL_PER_TICK) + last_tick_write_val_2 * (1 - SMOOTHING_OF_WRITE_VAL_PER_TICK); // smooth out write vals to prevent spikes
                current_write_val_2 = (current_write_val_2 > 1.0) ? 1.0 : (current_write_val_2 <= 0.0) ? 0.0 : current_write_val_2;
                
                if(desired_speed_2 < 0.1){pwm2.write(1.0);}
                else{pwm2.write(current_write_val_2);}

                // last_tick_write_val_2 = current_write_val_2;

                state = normal;
                calculatingPID = false;
                break;
            case calibrate_sensors:
                if(!calibrating_sensors){
                    lineSensorManager.stop_sampling_all();
                    stop_calibrating_sensors.attach(&go_to_normal, 1.0);
                    calibrating_sensors = true;
                    lineSensorManager.enableBank1();
                    lineSensorManager.enableBank2();
                    for (int i = 1; i <= 5; i++){
                        lineSensorManager.setSensorMax(i, 0.0);
                        lineSensorManager.setSensorMin(i, 1.0);
                    }
                    direction1 = 0;
                    direction2 = 1;
                    lineSensorManager.start_sampling_all(LINESENSOR_POLL_RATE);
                    calibration_count = 0;
                }
                else{
                    calibration_count++;
                    if(calibration_count > 3000){
                        // go_to_normal();
                        state = print_sensor_values;
                        t.detach();
                        direction1 = 1;
                        direction2 = 0;
                        break;
                    }
                    pid_output_1 = 0.0;
                    pid_output_1 = - first_motor_controller.calculate((double)encoder1.getRPS(), 2.0);        
                    current_write_val_1 = (pid_output_1 * SMOOTHING_OF_WRITE_VAL_PER_TICK) + (last_tick_write_val_1 * (1- SMOOTHING_OF_WRITE_VAL_PER_TICK)); // smooth out write vals to prevent spikes
                    current_write_val_1 = (current_write_val_1 >= 1.0) ? 1.0 : (current_write_val_1 <= 0.0) ? 0.0 : current_write_val_1;
                    pwm1.write((float)current_write_val_1);
                    // last_tick_write_val_1 = current_write_val_1;

                    pid_output_2 = 0.0;
                    pid_output_2 = - second_motor_controller.calculate((double)encoder2.getRPS(), 2.0);        
                    current_write_val_2 = (pid_output_2 * SMOOTHING_OF_WRITE_VAL_PER_TICK) + (last_tick_write_val_2 * (1- SMOOTHING_OF_WRITE_VAL_PER_TICK)); // smooth out write vals to prevent spikes
                    current_write_val_2 = (current_write_val_2 >= 1.0) ? 1.0 : (current_write_val_2 <= 0.0) ? 0.0 : current_write_val_2;
                    pwm2.write((float)current_write_val_2);
                    // last_tick_write_val_2 = current_write_val_2;
                    // printf("Write1 = %lf\n", current_write_val_1);
                    // printf("Write2 = %lf\n", current_write_val_2);
                    

                    sensor_1_read = lineSensorManager.getAverageSensorValue(1, false);
                    if(sensor_1_read > lineSensorManager.getSensorMax(1)){lineSensorManager.setSensorMax(1, sensor_1_read);}
                    else if (sensor_1_read < lineSensorManager.getSensorMin(1)){lineSensorManager.setSensorMin(1, sensor_1_read);}

                    sensor_2_read = lineSensorManager.getAverageSensorValue(2, false);
                    if(sensor_2_read > lineSensorManager.getSensorMax(2)){lineSensorManager.setSensorMax(2, sensor_2_read);}
                    else if (sensor_2_read < lineSensorManager.getSensorMin(2)){lineSensorManager.setSensorMin(2, sensor_2_read);}

                    sensor_3_read = lineSensorManager.getAverageSensorValue(3, false);
                    if(sensor_3_read > lineSensorManager.getSensorMax(3)){lineSensorManager.setSensorMax(3, sensor_3_read);}
                    else if (sensor_3_read < lineSensorManager.getSensorMin(3)){lineSensorManager.setSensorMin(3, sensor_3_read);}

                    sensor_4_read = lineSensorManager.getAverageSensorValue(4, false);
                    if(sensor_4_read > lineSensorManager.getSensorMax(4)){lineSensorManager.setSensorMax(4, sensor_4_read);}
                    else if (sensor_4_read < lineSensorManager.getSensorMin(4)){lineSensorManager.setSensorMin(4, sensor_4_read);}

                    sensor_5_read = lineSensorManager.getAverageSensorValue(5, false);
                    if(sensor_5_read > lineSensorManager.getSensorMax(5)){lineSensorManager.setSensorMax(5, sensor_5_read);}
                    else if (sensor_5_read < lineSensorManager.getSensorMin(5)){lineSensorManager.setSensorMin(5, sensor_5_read);}
                }
                
                state = normal;
                break;
            case print_sensor_values:
                wait(0.5);
                enable = 0;
                wait(0.2);
                char data [12];

                printf("State = printvalues");

                wait(0.1);

                sprintf(data, "S1 Max = %1.3f", (float)(lineSensorManager.getSensorMax(1)));
                ble.transmitData(data, 12);
                sprintf(data, "S1 Min = %1.3f", (float)(lineSensorManager.getSensorMin(1)));
                ble.transmitData(data, 12);

                wait(0.1);

                sprintf(data, "S2 Max = %1.3f", (float)(lineSensorManager.getSensorMax(2)));
                ble.transmitData(data, 12);
                sprintf(data, "S2 Min = %1.3f", (float)(lineSensorManager.getSensorMin(2)));
                ble.transmitData(data, 12);

                wait(0.1);

                sprintf(data, "S3 Max = %1.3f", (float)(lineSensorManager.getSensorMax(3)));
                ble.transmitData(data, 12);
                sprintf(data, "S3 Min = %1.3f", (float)(lineSensorManager.getSensorMin(3)));
                ble.transmitData(data, 12);

                wait(0.1);

                sprintf(data, "S4 Max = %1.3f", (float)(lineSensorManager.getSensorMax(4)));
                ble.transmitData(data, 12);
                sprintf(data, "S4 Min = %1.3f", (float)(lineSensorManager.getSensorMin(4)));
                ble.transmitData(data, 12);

                wait(0.1);

                sprintf(data, "S5 Max = %1.3f", (float)(lineSensorManager.getSensorMax(5)));
                ble.transmitData(data, 12);
                sprintf(data, "S5 Min = %1.3f", (float)(lineSensorManager.getSensorMin(5)));
                ble.transmitData(data, 12);

                wait(0.1);

                calibrating_sensors = false;
                wait(0.5);
                enable = 1;
                state = normal;
                // stop_calibrating_sensors.attach(&enable_tickers, 0.5);
                enable_tickers();
                printf("Enabled Tickers!");
                printf("State = %d", state);                
                break;
            case reset_controllers:
                first_motor_controller.reset();
                second_motor_controller.reset();
                navigation_controller.reset();
                state = normal;
                break;
            case stop:
                printf("Stopping\n");
                desired_speed_1 = 0.0;
                desired_speed_2 = 0.0;
                enable = 0;
                state = normal;
                break;                

            case do_uturn_stuff:
                if(!isTurning){
                    // disable_tickers();
                    isTurning = true;
                    direction1 = 1;
                    direction2 = 1;
                    turn_count = 0;
                    canStopTurning = false;

                    prev_desired_speed_1 = desired_speed_1;
                    prev_desired_speed_2 = desired_speed_2;
                    
                }
                turn_count++;

                // wait until we lose the line to allow the buggy to stop turning
                if(!canStopTurning && (lineSensorManager.getAverageSensorValue(1) < TURNING_LOSE_LINE_READING && lineSensorManager.getAverageSensorValue(2) < TURNING_LOSE_LINE_READING && lineSensorManager.getAverageSensorValue(3) < TURNING_LOSE_LINE_READING && lineSensorManager.getAverageSensorValue(4) < TURNING_LOSE_LINE_READING && lineSensorManager.getAverageSensorValue(5) < TURNING_LOSE_LINE_READING) && turn_count > 500){
                    canStopTurning = true;
                }

                if(canStopTurning && (lineSensorManager.getAverageSensorValue(1) > TURNING_STOP_SENSOR_READING || lineSensorManager.getAverageSensorValue(4) > TURNING_STOP_SENSOR_READING) || turn_count > 5000){
                    // disable_tickers();
                    // enable = 0;
                    state = return_to_normal_after_finished_turn;
                    break;
                }

                pid_output_1 = 0.0;
                pid_output_1 = - first_motor_controller.calculate(encoder1.getRPS(), DEFAULT_TURN_SPEED);        
                current_write_val_1 = (pid_output_1 * SMOOTHING_OF_WRITE_VAL_PER_TICK) + last_tick_write_val_1 * (1 - SMOOTHING_OF_WRITE_VAL_PER_TICK); // smooth out write vals to prevent spikes
                current_write_val_1 = (current_write_val_1 > 1.0) ? 1.0 : (current_write_val_1 <= 0.0) ? 0.0 : current_write_val_1;
                pwm1.write(current_write_val_1);

                pid_output_2 = 0.0;
                pid_output_2 = - second_motor_controller.calculate(encoder2.getRPS(), DEFAULT_TURN_SPEED);        
                current_write_val_2 = (pid_output_2 * SMOOTHING_OF_WRITE_VAL_PER_TICK) + last_tick_write_val_2 * (1 - SMOOTHING_OF_WRITE_VAL_PER_TICK); // smooth out write vals to prevent spikes
                current_write_val_2 = (current_write_val_2 > 1.0) ? 1.0 : (current_write_val_2 <= 0.0) ? 0.0 : current_write_val_2;
                pwm2.write(current_write_val_2);              

                // printf("Value = %f", (float)(lineSensorManager.getAverageSensorValue(5)));
                // wait(0.001);
                state = normal;
                break;
            case return_to_normal_after_finished_turn:
                printf("stopping turn");
                // disable_tickers();
                
                // enable = 0;
                // wait(0.5);
                // enable = 1;
                // first_motor_controller.reset();
                // second_motor_controller.reset();

                // revert_to_normal_speeds_after_turn();

                prev_desired_speed_1 = RUNNING_SPEED;
                prev_desired_speed_2 = RUNNING_SPEED;

                desired_speed_1 = RUNNING_SPEED;
                desired_speed_2 = RUNNING_SPEED;
                // return_to_normal_speed.attach(&revert_to_normal_speeds_after_turn, 0.5);
                
                state = normal;
                isTurning = false;
                enable_tickers();
                break;

            case togglePrint:
                printSerial = !printSerial;
                if(printSerial){
                    t.attach(&printData, DATA_MEASURE_FREQ);
                }
                else{
                    t.detach();
                }
                state = normal;
                break;
            case change_val:
                disable_tickers();
                switch(value){
                    case speed1:
                        if(changeTo < 0.0){desired_direction_1 = 0;}else{desired_direction_1 = 1;}
                            desired_speed_1 = abs(changeTo);
                            prev_desired_speed_1 = abs(changeTo);
                        break;
                    case speed2:
                        if(changeTo < 0.0){desired_direction_2 = 0;}else{desired_direction_2 = 1;}
                            desired_speed_2 = abs(changeTo);
                            prev_desired_speed_2 = abs(changeTo);
                        break;
                    case pro1:
                        first_motor_controller.setP((double)changeTo);
                        break;
                    case int1:
                        first_motor_controller.setI((double)changeTo);
                        first_motor_controller.reset();
                        break;
                    case der1:
                        first_motor_controller.setD((double)changeTo);
                        first_motor_controller.reset();
                        break;
                    case pro2:
                        second_motor_controller.setP((double)changeTo);
                        break;
                    case int2:
                        second_motor_controller.setI((double)changeTo);
                        second_motor_controller.reset();
                        break;
                    case der2:
                        second_motor_controller.setD((double)changeTo);
                        second_motor_controller.reset();
                        break;
                    case pro3:
                        navigation_controller.setP((double)changeTo);
                        break;
                    case int3:
                        navigation_controller.setI((double)changeTo);
                        navigation_controller.reset();
                        break;
                    case der3:
                        navigation_controller.setD((double)changeTo);
                        navigation_controller.reset();
                        break;
                    case slow_cond:
                        slow_condition = (double)(changeTo);
                        break;
                    case slow_speed_val:
                        slow_speed = (double)(changeTo);
                        break;
                    case turn_speed_val:
                        turning_speed = (double)(changeTo);
                        break;
                }
                enable_tickers();
                state = normal;
                break;
        }
    }
}