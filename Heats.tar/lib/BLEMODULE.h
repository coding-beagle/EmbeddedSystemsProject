#ifndef BLEMODULE_H
#define BLEMODULE_H
#include "mbed.h"

#define ACCEPTABLE_BAUDS 9600, 19200, 38400, 57600, 115200, 4800, 2400, 1200, 230400 // as per spec sheet
#define NUMBER_OF_BAUDS 9
#define COMMAND_LENGTH 2
#define OUTPUT_BUFFER_SIZE 50
#define NUMBER_OF_COMMANDS 25

/// This is a utility class for simplifying the handling of BLE via the HM10 module.
class HM10{
    private:
        struct callbacks{
                int signal;
                Callback<void()> callback;
                Callback<void(int)> callback_int;
                Callback<void(float)> callback_float;
                bool inUse;
                bool takesInt;
                bool takesFloat;
            };
                
        Serial bleModule;

        int input;

        callbacks callbacksArray[NUMBER_OF_COMMANDS]; // max of ten callbacks i guess

        /// Clears internal callback buffers.
        ///
        /// Called automatically upon instantiation.
        void init();

        /// Decode 4 incoming chars into a single float. Called when a signal for a function with a float argument is received.
        ///
        /// 
        /// This specific implementation requires the user to send 4
        /// chars in succession, starting from the least significant byte.
        /// 
        /// Failure to send 4 chars will halt the program, which can be
        /// found if the bluetooth device does not echo the received float
        /// back to the sender. E.g. 'Called with xx.xxxx' will be echoed
        /// once all bytes are received.
        ///
        /// @returns The received float.
        ///               
        float incoming_to_float();

    public:

        /// Class constructor.
        ///
        /// @param rx RX Pin of BLE Module. This should be connected to a corresponding TX pin of a UART peripherial of the Nucleo.
        /// @param tx TX Pin of BLE Module. This should be connected to a corresponding RX pin of a UART peripherial of the Nucleo. 
        HM10(PinName rx, PinName tx);

        /// Class constructor with baudrate shortcut.
        ///
        /// @param rx RX Pin of BLE Module. This should be connected to a corresponding TX pin of a UART peripherial of the Nucleo.
        /// @param tx TX Pin of BLE Module. This should be connected to a corresponding RX pin of a UART peripherial of the Nucleo. 
        /// @param baud Desired baudrate for running the HM10 module. Should match with the configured rate set previously, which is 9600 in this case.
        HM10(PinName rx, PinName tx, int baud);

        /// Change the Baud Rate that the HM10 Module is running on.
        ///
        /// Can only be one of the specified Baud rates specified on the HM10 specsheet.
        ///
        /// @param baud The baud rate to change the HM10 communications to.
        /// 
        /// @returns 0 on successful change, -1 if failed (i.e. Baud rate is invalid)                                      
        ///
        int setBaud(int baud);

        ///  Assign a callback to run when the signal number is sent
        ///  through BLE. 
        ///
        ///  @param signal The value that must be received by the HM10 module to trigger the callback.
        ///  @param cb     The callback that gets executed when 'signal' is received over bluetooth.
        ///
        ///  @returns 0 if the callback is successfully added, -1 if not (i.e. all callback slots used)          
        ///
        int addCallback(int signal, Callback<void()> cb);

        ///  Assign a callback to run when the signal number is sent
        ///  through BLE.
        ///
        ///  Takes an extra char being sent as the argument for the callback.
        ///
        ///  @param signal The value that must be received by the HM10 module to trigger the callback.
        ///  @param cb     The callback that gets executed when 'signal' is received over bluetooth.
        ///
        ///  @returns 0 if the callback is successfully added, -1 if not (i.e. all callback slots used)          
        ///
        int addCallback(int signal, Callback<void(int)> cb);

        ///  Assign a callback to run when the signal number is sent
        ///  through BLE.
        ///
        ///  Takes an extra 4 chars being sent as the argument for the callback.
        ///
        ///  @param signal The value that must be received by the HM10 module to trigger the callback.
        ///  @param cb     The callback that gets executed when 'signal' is received over bluetooth.
        ///
        ///  @returns 0 if the callback is successfully added, -1 if not (i.e. all callback slots used)          
        ///
        int addCallback(int signal, Callback<void(float)> cb);

        /// Remove a callback by passing in the signal that is supposed
        /// to trigger it.
        ///
        /// @param signal Which signal to remove from the internal callback buffer.
        ///
        /// @returns 0 if the callback is successfully removed, -1 if not, i.e. signal doesn't exist              
        ///
        int removeCallback(int signal);

        /// Transmit data through bluetooth. 
        /// ## This is a blocking call. ##
        ///
        /// @param data Pointer to string buffer to be sent.
        /// @param len  length of the string buffer. 
        ///
        /// @returns 0 on successful transmission  
        ///                                                            
        int transmitData(const char* data, const int len);

        /// Main Loop of BLE handling. Must be called every cycle, as this
        /// checks whether the BLE device is receiving data.          
        /// 
        /// ## This is a blocking call. ##
        ///
        /// If a function that requires an argument to be called is
        /// received through bluetooth, then the main loop will be
        /// interrupted to wait for the bluetooth command.
        /// 
        /// If the function requires an int, then we expect one value 
        /// through bluetooth (uint8_t).
        /// If the function requires a float, then we expect four values
        /// (uint8_t) x 4. 
        ///
        void doBLE();

};


#endif
