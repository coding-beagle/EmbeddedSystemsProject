#ifndef PID_H
#define PID_H

#include <mbed.h>

/// A utility class to handle PID controller responsibilities.
class PIDController {
private:
    double prop_const;       // Proportional gain
    double int_const;        // Integral gain
    double deriv_const;      // Derivative gain
    double dt;              // Time between sensor polls
    double previous_error;  // error previous delta t (for deriv)
    double error;
    double integral_sum;

public:
    /// Class constructor.
    ///
    /// @param prop The proportional gain constant.
    /// @param integ The integral gain constant.
    /// @param deriv The derivative gain constant.
    /// @param dt The period of the PID loop.
    PIDController(double prop, double integ, double deriv, double dt);

    /// Change the proportional gain constant.
    ///
    /// Useful for being able to dynamically change PID values.
    /// ## Note that for this change to take place, the ticker running the control loop needs to be restarted. 
    ///
    /// Used in PID control algorithm. The proportional term is proportional 
    /// to the current error signal. It provides an immediate response to 
    /// the current error.
    ///
    /// @param value The value to which the gain should be changed to.
    void setP(double value);

    /// Change the integral gain constant.
    ///
    /// Useful for being able to dynamically change PID values.
    /// ## Note that for this change to take place, the ticker running the control loop needs to be restarted. 
    ///
    /// Used in PID control algorithm. The integral term is proportional to 
    /// both the magnitude and the duration of the error. It accumulates the
    /// error over time and acts to eliminate steady-state errors.
    ///
    /// @param value The value to which the gain should be changed to.
    void setI(double value);

    /// Change the derivative gain constant.
    ///
    /// Useful for being able to dynamically change PID values.
    /// ## Note that for this change to take place, the ticker running the control loop needs to be restarted. 
    ///
    /// Used in PID control algorithm. The derivative term is proportional to 
    /// the rate of change of the error. It predicts future behavior of the 
    /// error based on its current rate of change. It provides damping or 
    /// stabilizing effect by anticipating future trends in the error and 
    /// counteracting them.
    ///
    /// @param value The value to which the gain should be changed to.
    void setD(double value);

    /// Return the current derivative gain constant.
    ///
    /// Useful for debugging purposes.
    ///
    /// @returns The current proportional gain value.
    double getP();

    /// Return the current integral gain constant.
    ///
    /// Useful for debugging purposes.
    ///
    /// @returns The current integral gain value.
    double getI();

    /// Return the current derivative gain constant.
    ///
    /// Useful for debugging purposes.
    ///
    /// @returns The current derivative gain value.
    double getD();

    /// Resets the previous error value.
    ///
    /// E.g. the internal previous error value and accumulated error value.
    /// Useful for when the setpoint changes, but seldom used.
    void reset();

    /// Return the output of the PID controller.
    ///
    /// @param current_val The current value of the PID system.
    /// @param desired_val The set point of the PID system.
    ///
    /// @returns The output of the PID controller, based on the set constants.
    double calculate(double current_val, double desired_val);
};

#endif