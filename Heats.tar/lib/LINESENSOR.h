#ifndef LINESENSOR_H
#define LINESENSOR_H
#include "mbed.h"

#define sensor_1_buffer_size 3
#define sensor_2_buffer_size 3
#define sensor_3_buffer_size 3
#define sensor_4_buffer_size 3
#define sensor_5_buffer_size 2

/// A utility class to encapsulate all of the logic for handling the line sensor readings.
class LineSensor {
private:
    AnalogIn sensor1;
    AnalogIn sensor2;
    AnalogIn sensor3;
    AnalogIn sensor4;
    AnalogIn sensor5;
    DigitalOut enablePin1; // Pin connected to Darlington array for sensor 1
    DigitalOut enablePin2; // Pin connected to Darlington array for sensor 2
    Timer timer;

    int lastcounts;

    double sensor1_values[sensor_1_buffer_size];
    int sensor1_index;
    double sensor2_values[sensor_2_buffer_size];
    int sensor2_index;
    double sensor3_values[sensor_3_buffer_size];
    int sensor3_index;
    double sensor4_values[sensor_4_buffer_size];
    int sensor4_index;
    double sensor5_values[sensor_5_buffer_size];
    int sensor5_index;

    double averageSensorValue1;
    double averageSensorValue2;
    double averageSensorValue3;
    double averageSensorValue4;
    double averageSensorValue5;

    // adjust values as needed in lab
    double sensor1Max;
    double sensor1Min;
    
    double sensor2Max;
    double sensor2Min;

    double sensor3Max;
    double sensor3Min;

    double sensor4Max;
    double sensor4Min;

    double sensor5Max;
    double sensor5Min;

    Ticker t;

    double normalize(int sensorNum);

    void readAll();

    double getRaw(int sensorNum);


public:
    /// Constructor to initialize sensors and enable pins.
    ///
    /// @param enablePin1 => The pin to enable the first bank of sensors on the board.
    /// @param enablePin2 => The pin to enable the second bank of sensors on the board.
    ///
    /// @param pin1 => Analog pin which is connected to the first sensor.
    /// @param pin2 => Analog pin which is connected to the second sensor.
    /// @param pin3 => Analog pin which is connected to the third sensor.
    /// @param pin4 => Analog pin which is connected to the fourth sensor.
    /// @param pin5 => Analog pin which is connected to the fifth sensor.
    LineSensor(PinName enablePin1, PinName enablePin2,
               PinName pin1, PinName pin2, PinName pin3, PinName pin4, PinName pin5);

    /// Enables the first bank of sensors.
    ///
    /// Sets the GPIO set as enablePin1 in @see LineSensor() to high.
    void enableBank1();
    /// Disables the first bank of sensors.
    ///
    /// Sets the GPIO set as enablePin1 in @see LineSensor() to low.
    void disableBank1();

    /// Enables the second bank of sensors.
    ///
    /// Sets the GPIO set as enablePin2 in @see LineSensor() to high.
    void enableBank2();
    /// Disables the second bank of sensors.
    ///
    /// Sets the GPIO set as enablePin2 in @see LineSensor() to low.
    void disableBank2();

    /// Return an averaged reading from a specific sensor.
    ///
    /// @param sensorNumber => The sensor (1-5) from which to return data.
    /// @param normalize => Whether or not to constrain the output between 0-1 based on values set in @see setSensorMax() setSensorMin()
    ///
    /// @returns The averaged value of the sensor reading.
    float getAverageSensorValue(int sensorNumber, bool normalize=true);

    /// Explicitly sample a specific sensor.
    ///
    /// This is called internally in @see start_sampling_all()
    /// and should only be used if a longer sample period is desired, or for debugging purposes.
    ///
    /// @param sensorNumber => The sensor (1-5) from which to sample.
    void readSensorValues(int sensorNumber);
    
    /// Start the internal ticker to automatically sample all of the sensor readings.
    ///
    /// The sensor readings get stored in an internal buffer, which can be changed as a part
    /// of the macros at the top of LINESENSOR.h
    ///
    /// @param sample_period => How often to sample each sensor, in s.
    void start_sampling_all(float sample_period);

    /// Stops the internal ticker from sampling all of the sensor readings.
    void stop_sampling_all();

    /// Set the upper bound of what reading is expected from the sensor.
    ///
    /// This can be used in conjunction with a calibration routine and
    /// the normalized reading in @see getAverageSensorValue() in order to
    /// represent the white line as a value of 1.0.
    ///
    /// @param sensorNumber => Chooses which sensor (1-5) whose maximum value is to be changed.
    /// @param maxValu => Set the maximum value that is expected from that sensor.
    void setSensorMax(int sensorNumber, double maxValu);

    /// Set the lower bound of what reading is expected from the sensor.
    ///
    /// This can be used in conjunction with a calibration routine and
    /// the normalized reading in @see getAverageSensorValue() in order to
    /// represent the dark parts of the track as a value of 0.0.
    ///
    /// @param sensorNumber => Chooses which sensor (1-5) whose maximum value is to be changed.
    /// @param minValu => Set the minimum value that is expected from that sensor.
    void setSensorMin(int sensorNumber, double minValu);

    /// Returns the current value used as the maximum expected for a specific sensor.
    ///
    /// Useful in calibration routines, in conjunction with @see getAverageSensorValue()
    /// as the return value from that can be checked against this in order to see whether
    /// or not the current value exceeds the maximum expected. If so, change the maximum
    /// to be the new value.
    ///
    /// @param sensorNumber => Which sensor (1-5) maximum to return.
    double getSensorMax(int sensorNumber);

    /// Returns the current value used as the minimum expected for a specific sensor.
    ///
    /// Useful in calibration routines, in conjunction with @see getAverageSensorValue()
    /// as the return value from that can be checked against this in order to see whether
    /// or not the current value subceeds the minimu, expected. If so, change the minimum
    /// to be the new value.
    ///
    /// @param sensorNumber => Which sensor (1-5) minimum to return.
    double getSensorMin(int sensorNumber);
};

#endif