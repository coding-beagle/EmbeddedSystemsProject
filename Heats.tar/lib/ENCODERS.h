#ifndef ENCODERS_H
#define ENCODERS_H
#include "mbed.h"

#define ROLLING_AVERAGE_DATA_POINTS 20

/// A utility class for encapsulating the logic of the Encoder modules.
class Encoder{
    private:
        InterruptIn channelA, channelB;
        int pulses, revolutions, pulses_per_rev, rps_index;
        float RPS, wheel_diameter, calc_period;
        Ticker t;
        float previous_rps[ROLLING_AVERAGE_DATA_POINTS];

        void increment();

        void calculateRPS();

    public:
        /// Class constructor.
        ///
        /// Starts a ticker internally with period of **period**, which executes the logic for measuring rotation speeds.
        ///
        /// @param channel1 The pin of channelA
        /// @param channel2 The pin of channelB
        /// @param PPR Pulses Per Revolution, how many pulses per each full revolution of the wheel.
        /// @param wheel Wheel diameter in m.
        /// @param period Period of sampling encoder rotations.
        Encoder(PinName channel1, PinName channel2, int PPR, float wheel, float period);
        
        /// Function to get current pulse count.
        ///
        /// Called internally as a part of the sampling routine. Called every sample period, along with the private calculateRPS function.
        ///
        /// @returns Number of pulses in previous measurment period.
        int getPulses();

        /// Explicitly reset the amount of pulses counted.
        ///
        /// Called right after both getPulses function and calculateRPS function are executed beofre next iteration in main loop to get latest speed.
        void clearPulses();

        /// Explicitly reset the revolutions per second counted.
        ///
        /// Called along with clearPulses function before next iteration in main loop to get latest speed.
        void clearRPS();

        /// Return the revolutions / s counted as a part of the previous cycle.
        ///
        /// This value is rolling-averaged, which can be changed as a part of the macros
        /// in ENCODERS.h. 
        /// Called in PID control algorithm to get current speed and then setting it to a desired speed.
        ///
        /// @returns the revolutions / s count of the previous measurement period.
        float getRPS();
        
        /// Return the m / s counted as a part of the previous cycle.
        ///
        /// This value is rolling-averaged, which can be changed as a part of the macros
        /// in ENCODERS.h
        ///
        /// @returns the m / s count of the previous measurement period.
        float getMPS();
};

#endif